# RuStore APK AutoInstall (Magisk Module)

Repository: https://github.com/Fariarx/RuStoreAutoinstall

This module scans:

`/data/data/ru.vk.store/files/apkStorage`

and all nested folders for `*.zip` archives, extracts `*.apk`, installs them,
updates already installed apps, and then removes ZIP only when all APK from
that ZIP were installed successfully.

Main trigger is the Magisk module **Action** button (`action.sh`), so you can
run it manually without reboot.
Boot trigger is disabled.

## What it does

1. Searches recursively for `.zip` archives.
2. Tries direct install of the archive path (if it is actually installable).
3. Extracts APK files from ZIP.
4. Installs APKs:
   - `pm install-multiple -r --user 0` for multi-APK/split sets.
   - Fallback to `pm install -r --user 0` one-by-one.
5. Deletes ZIP only when all APK from that ZIP were installed successfully.
6. Writes logs to:
   - `/data/local/tmp/rustore-apk-autoinstall/install.log`

## Module files

- `module.prop`
- `installer.sh`
- `service.sh`
- `action.sh`
- `customize.sh`
- `skip_mount`

## Build ZIP for Magisk app

From the module folder:

```sh
zip -r RuStore-AutoInstall-Manual-v1.0.0.zip module.prop installer.sh service.sh action.sh customize.sh skip_mount README.md
```

Then install this ZIP from Magisk app.

## Run without reboot

After installing module, open Magisk app, go to this module and press
**Action**.
